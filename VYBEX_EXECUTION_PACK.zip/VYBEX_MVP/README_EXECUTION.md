# VYBEX execution pack

This build includes three original, faceless vertical MP4s in `videos/` and a ready-to-publish queue in `content/publish_queue.json`.

## Publish immediately
The included `backend/tiktok_client.py` implements TikTok Content Posting API Direct Post using `video.publish`. Configure the TikTok app, OAuth callback, and authorized user token as environment variables on the deployed backend. TikTok requires approval/authorization for public Direct Posts; unaudited clients are private-only.

## Important
The videos contain no third-party footage, TikTok watermarks, or VYBEX promotional watermark. They are original generated graphics + locally generated voiceover.
