# VYBEX MVP

VYBEX is a faceless short-form content intelligence platform.

## Included
- Trend discovery API with transparent viral scoring
- SQLite persistence
- Content idea/script generation (demo mode works without an AI key)
- Content queue and approval workflow
- TikTok OAuth/Direct Post adapter scaffold
- Dashboard UI
- Scheduled GitHub Actions trend refresh
- Docker support
- Safe default: publishing requires explicit approval

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r backend/requirements.txt
uvicorn backend.main:app --reload --port 8000
```

Open http://localhost:8000

## Environment
Copy `.env.example` to `.env`.

TikTok credentials are intentionally not included. Configure them only in your deployment secret store.

## TikTok
The adapter is prepared for TikTok Content Posting API OAuth and Direct Post. Actual posting remains disabled until the TikTok app is approved and the creator explicitly authorizes the account.

## Production architecture
The MVP is intentionally simple:
Frontend -> FastAPI -> SQLite
It can later move to PostgreSQL and object storage without changing the product model.
