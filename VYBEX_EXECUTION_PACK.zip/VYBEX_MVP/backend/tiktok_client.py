import os, math, requests
from pathlib import Path

API='https://open.tiktokapis.com'

def _headers(token): return {'Authorization':f'Bearer {token}','Content-Type':'application/json; charset=UTF-8'}

def creator_info(token):
    r=requests.post(f'{API}/v2/post/publish/creator_info/query/',headers=_headers(token),timeout=30); r.raise_for_status(); return r.json()

def direct_post_file(token, video_path, caption, privacy='PUBLIC_TO_EVERYONE'):
    p=Path(video_path); size=p.stat().st_size
    chunk=min(10*1024*1024,size); total=math.ceil(size/chunk)
    body={'post_info':{'title':caption,'privacy_level':privacy,'disable_duet':False,'disable_comment':False,'disable_stitch':False},'source_info':{'source':'FILE_UPLOAD','video_size':size,'chunk_size':chunk,'total_chunk_count':total}}
    r=requests.post(f'{API}/v2/post/publish/video/init/',headers=_headers(token),json=body,timeout=30); r.raise_for_status(); data=r.json()['data']
    with p.open('rb') as f:
        for i in range(total):
            b=f.read(chunk); start=i*chunk; end=start+len(b)-1
            rr=requests.put(data['upload_url'],headers={'Content-Type':'video/mp4','Content-Length':str(len(b)),'Content-Range':f'bytes {start}-{end}/{size}'},data=b,timeout=120); rr.raise_for_status()
    return data.get('publish_id')

def status(token,publish_id):
    r=requests.post(f'{API}/v2/post/publish/status/fetch/',headers=_headers(token),json={'publish_id':publish_id},timeout=30); r.raise_for_status(); return r.json()
