import os, sqlite3, math, hashlib
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
import feedparser
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, RedirectResponse
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()
ROOT = Path(__file__).resolve().parent.parent
DB = Path(os.getenv("VYBEX_DB", ROOT / "vybex.db"))
app = FastAPI(title="VYBEX API", version="1.0.0")

RSS = [
    ("Google News", "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en"),
    ("Google News Tech", "https://news.google.com/rss/search?q=technology&hl=en-US&gl=US&ceid=US:en"),
    ("Google News Gaming", "https://news.google.com/rss/search?q=gaming&hl=en-US&gl=US&ceid=US:en"),
    ("Google News Weird", "https://news.google.com/rss/search?q=weird+news&hl=en-US&gl=US&ceid=US:en"),
]

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS trends(
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, url TEXT,
      source TEXT, score REAL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS content(
      id INTEGER PRIMARY KEY AUTOINCREMENT, trend_id INTEGER, title TEXT,
      hook TEXT, script TEXT, status TEXT DEFAULT 'draft',
      created_at TEXT NOT NULL, FOREIGN KEY(trend_id) REFERENCES trends(id)
    );
    """)
    c.commit(); c.close()

def score(title, summary=""):
    text=(title+" "+summary).lower()
    velocity = min(100, 35 + len(title)*1.2)
    engagement = 55 + min(25, sum(text.count(x) for x in ["viral","breaking","wow","new","game","ai","secret"])*5)
    freshness = 95
    momentum = min(100, 45 + len(set(text.split()))/2)
    return round(.30*velocity + .20*engagement + .10*70 + .15*60 + .15*freshness + .10*momentum, 1)

def refresh():
    c=db()
    seen=set()
    count=0
    for source,url in RSS:
        feed=feedparser.parse(url)
        for e in feed.entries[:25]:
            title=e.get("title","").strip()
            link=e.get("link","")
            if not title or title in seen: continue
            seen.add(title)
            c.execute("INSERT INTO trends(title,url,source,score,created_at) VALUES(?,?,?,?,?)",
                      (title,link,source,score(title,e.get("summary","")),datetime.now(timezone.utc).isoformat()))
            count+=1
    c.commit(); c.close()
    return count

class GenerateRequest(BaseModel):
    trend_id:int

class StatusRequest(BaseModel):
    status:str

@app.on_event("startup")
def startup():
    init()
    c=db(); n=c.execute("SELECT COUNT(*) n FROM trends").fetchone()["n"]; c.close()
    if n==0: refresh()

@app.get("/")
def home():
    return FileResponse(ROOT/"frontend/index.html")

@app.get("/api/health")
def health():
    return {"ok":True,"service":"VYBEX","publishing_enabled":os.getenv("PUBLISHING_ENABLED","false")=="true"}

@app.post("/api/trends/refresh")
def trends_refresh():
    return {"added":refresh()}

@app.get("/api/trends")
def trends(limit:int=30):
    c=db()
    rows=c.execute("SELECT * FROM trends ORDER BY score DESC, id DESC LIMIT ?",(limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]

@app.get("/api/content")
def content():
    c=db(); rows=c.execute("SELECT * FROM content ORDER BY id DESC").fetchall(); c.close()
    return [dict(r) for r in rows]

@app.post("/api/content/generate")
def generate(req:GenerateRequest):
    c=db(); t=c.execute("SELECT * FROM trends WHERE id=?",(req.trend_id,)).fetchone()
    if not t: raise HTTPException(404,"Trend not found")
    title=t["title"]
    hook=f"Nobody is talking about this part of {title}…"
    script=f"""HOOK: {hook}

SETUP: Here's what just happened: {title}

TWIST: The detail most people will miss is what makes this interesting.

VALUE: Explain the story in simple, fast sentences. Keep the pacing tight and add captions for every key beat.

CTA: Follow VYBEX for the next story before it blows up."""
    cur=c.execute("INSERT INTO content(trend_id,title,hook,script,status,created_at) VALUES(?,?,?,?,?,?)",
                  (t["id"],title,hook,script,"draft",datetime.now(timezone.utc).isoformat()))
    c.commit(); cid=cur.lastrowid; c.close()
    return {"id":cid,"title":title,"hook":hook,"script":script,"status":"draft"}

@app.patch("/api/content/{content_id}")
def update_content(content_id:int, req:StatusRequest):
    allowed={"draft","approved","published","rejected"}
    if req.status not in allowed: raise HTTPException(400,"Invalid status")
    c=db(); cur=c.execute("UPDATE content SET status=? WHERE id=?",(req.status,content_id))
    c.commit(); c.close()
    if not cur.rowcount: raise HTTPException(404,"Content not found")
    return {"ok":True}

@app.get("/api/tiktok/authorize")
def tiktok_authorize():
    key=os.getenv("TIKTOK_CLIENT_KEY")
    redirect=os.getenv("TIKTOK_REDIRECT_URI")
    if not key: return {"configured":False,"message":"TikTok credentials not configured"}
    params={"client_key":key,"scope":"user.info.basic,video.publish","response_type":"code",
            "redirect_uri":redirect,"state":"vybex"}
    return RedirectResponse("https://www.tiktok.com/v2/auth/authorize/?" + urlencode(params))

@app.get("/api/tiktok/callback")
def tiktok_callback(code:str|None=None):
    if not code: return {"ok":False,"message":"Authorization code missing"}
    return {"ok":True,"message":"Authorization received. Token exchange should be performed server-side."}
