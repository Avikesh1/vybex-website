# Deployment

## Cheapest path
Deploy the FastAPI container to any free/low-cost container host that supports Docker, then point the public VYBEX website's Studio button to the application URL.

## Production checklist
1. Set all secrets as environment variables.
2. Set `PUBLISHING_ENABLED=false` until TikTok approval.
3. Use PostgreSQL instead of SQLite when running multiple instances.
4. Put generated video files in object storage rather than the application filesystem.
5. Add HTTPS.
6. Configure the TikTok redirect URI to the exact HTTPS callback URL.
7. Complete TikTok app review and only enable publishing after approval.
