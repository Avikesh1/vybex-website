from pathlib import Path
import subprocess, textwrap, json, math
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'videos'; AUDIO=OUT/'audio'; FRAMES=OUT/'frames'
AUDIO.mkdir(parents=True,exist_ok=True); FRAMES.mkdir(parents=True,exist_ok=True)
W,H=1080,1920
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONT_REG='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'

videos=[
 {"slug":"three-facts-that-sound-fake","title":"3 FACTS THAT SOUND FAKE","segments":[
   ("FACT 1","Octopuses have THREE hearts."),("FACT 2","Honey can stay edible for an incredibly long time when sealed."),("FACT 3","Botanically, bananas are berries."),
   ("FINAL","Which one surprised you most? Follow for tomorrow's weirdest facts.")],
  "voice":"Three facts that sound fake, but are true. Fact one: octopuses have three hearts. Fact two: honey can stay edible for an incredibly long time when sealed. Fact three: botanically, bananas are berries. Which one surprised you most? Follow for tomorrow's weirdest facts."},
 {"slug":"brain-glitch","title":"YOUR BRAIN DOES THIS WITHOUT ASKING","segments":[
   ("BRAIN GLITCH","Your brain can fill in missing information before you consciously notice it."),("EXAMPLE","That's why you can often read a sentence with missing letters and still understand it."),("WHY","Your brain uses context and patterns to predict what should be there."),("FINAL","Your brain is basically running autocomplete. Follow for more weird science.")],
  "voice":"Your brain can fill in missing information before you consciously notice it. That's why you can often read a sentence with missing letters and still understand it. Your brain uses context and patterns to predict what should be there. Your brain is basically running autocomplete. Follow for more weird science."},
 {"slug":"internet-trap","title":"THE INTERNET MAKES THIS FEEL REAL","segments":[
   ("THE TRAP","Seeing something repeatedly can make it feel more familiar — and familiarity can feel like truth."),("THE PROBLEM","A claim appearing in ten posts does not automatically mean there are ten independent sources."),("QUICK CHECK","Before sharing: find the original source, check the date, and look for independent confirmation."),("FINAL","Don't let repetition do your fact-checking. Follow for smarter internet habits.")],
  "voice":"Seeing something repeatedly can make it feel more familiar, and familiarity can feel like truth. But a claim appearing in ten posts does not automatically mean there are ten independent sources. Before sharing, find the original source, check the date, and look for independent confirmation. Don't let repetition do your fact checking. Follow for smarter internet habits."}
]

def wrap(draw,text,font,max_width):
    words=text.split(); lines=[]; cur=''
    for w in words:
        test=(cur+' '+w).strip()
        if draw.textbbox((0,0),test,font=font)[2] <= max_width: cur=test
        else:
            if cur: lines.append(cur)
            cur=w
    if cur: lines.append(cur)
    return lines

def make_bg(path, seed):
    im=Image.new('RGB',(W,H)); px=im.load()
    for y in range(H):
        for x in range(W):
            # dark futuristic gradient, no brand watermark
            a=(x/W); b=(y/H)
            r=int(8+18*a+8*b); g=int(10+8*(1-a)+10*b); bl=int(22+34*(1-b)+20*a)
            glow=35*math.exp(-(((x-W*.72)/(W*.35))**2+((y-H*.25)/(H*.35))**2))
            px[x,y]=(min(255,int(r)),min(255,int(g+glow*.25)),min(255,int(bl+glow)))
    im.save(path,quality=95)

def tts(text,out):
    subprocess.run(['espeak','-s','172','-v','en-us',text,'-w',str(out)],check=True)

def duration(path):
    p=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)],capture_output=True,text=True,check=True)
    return float(p.stdout.strip())

queue=[]
for i,v in enumerate(videos):
    base=OUT/f'{i+1:02d}_{v["slug"]}'
    bg=base.with_suffix('.png'); wav=base.with_suffix('.wav'); mp4=base.with_suffix('.mp4')
    make_bg(bg,i)
    tts(v['voice'],wav)
    dur=duration(wav)
    # evenly distribute segments, with first/last slightly longer
    segdur=dur/len(v['segments'])
    filters=[]
    filters.append(f"[0:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},zoompan=z='min(zoom+0.0008,1.12)':d=1:s={W}x{H}:fps=30,format=yuv420p[bg]")
    cur='[bg]'
    for j,(label,body) in enumerate(v['segments']):
        start=j*segdur; end=(j+1)*segdur
        # escape for ffmpeg drawtext
        def esc(s): return s.replace('\\','\\\\').replace(':','\\:').replace("'",'’')
        filters.append(f"{cur}drawtext=fontfile={FONT}:text='{esc(label)}':fontcolor=white:fontsize=74:x=(w-text_w)/2:y=430:enable='between(t,{start:.3f},{end:.3f})'[a{j}]")
        cur=f'[a{j}]'
        filters.append(f"{cur}drawtext=fontfile={FONT_REG}:text='{esc(body)}':fontcolor=white:fontsize=58:line_spacing=18:x=(w-text_w)/2:y=(h-text_h)/2:box=1:boxcolor=black@0.58:boxborderw=34:enable='between(t,{start:.3f},{end:.3f})'[b{j}]")
        cur=f'[b{j}]'
    filters.append(f"{cur}drawtext=fontfile={FONT_REG}:text='Original • Faceless • Fast':fontcolor=white@0.72:fontsize=30:x=(w-text_w)/2:y=h-150:enable='between(t,{max(0,dur-3):.3f},{dur:.3f})'[vout]")
    fc=';'.join(filters)
    subprocess.run(['ffmpeg','-y','-loop','1','-i',str(bg),'-i',str(wav),'-filter_complex',fc,'-map','[vout]','-map','1:a','-t',f'{dur:.3f}','-r','30','-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(mp4)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    queue.append({"file":str(mp4.relative_to(ROOT)),"caption":v['title']+' #fyp #facts #weird #internet #viral',"status":"ready","duration_sec":round(dur,1)})

(Path(ROOT/'content'/'publish_queue.json')).write_text(json.dumps(queue,indent=2))
print(json.dumps(queue,indent=2))
