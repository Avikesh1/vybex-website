# Nexora AI — Final Testable MVP

Nexora is a local autonomous-business-assistant MVP. It converts objectives into an execution queue, researches/scorers demo prospects, generates content, manages tasks, stores state, and provides an AI-agent chat interface.

## Run
Requires Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000

## Live AI
Set an OpenAI API key before starting the server:

Linux/macOS:
```bash
export OPENAI_API_KEY="your_key"
export OPENAI_MODEL="gpt-5.6"
npm start
```

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="your_key"
$env:OPENAI_MODEL="gpt-5.6"
npm start
```

Without a key, Demo Mode remains fully testable. No external emails, messages, purchases, or other irreversible actions are performed.

## What is included
- Autonomous objective planner
- Persistent local business/task/lead/content state
- Lead research workflow (safe demo data)
- Content generation workflow
- AI agent chat
- Business profile
- Execution queue and completion tracking
- Live OpenAI Responses API integration
- Responsive dashboard

## Production roadmap
Real-world autonomy requires explicit credentials and provider APIs for email, CRM, calendar, web research, payments and messaging. Those connectors should be added with approval gates, audit logs, rate limits and secret storage before enabling irreversible actions.
